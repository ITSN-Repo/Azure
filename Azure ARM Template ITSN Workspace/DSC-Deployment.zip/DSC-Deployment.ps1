configuration xConfig {
    param (
        [parameter(mandatory)][string] $DomainName,
        [parameter(mandatory)][PSCredential] $AdminCreds,
        [int] $RetryCount = 90,
        [int] $RetryIntervalSec = 30
    )

    Import-DscResource -ModuleName xActiveDirectory, xNetworking, xStorage, xComputerManagement

    $DomainCreds = New-Object System.Management.Automation.PSCredential ("$DomainName\$($AdminCreds.UserName)", $adminCreds.Password)
    $Interface = Get-NetAdapter | Where-Object Name -like "Ethernet*" | Select-Object -First 1
    $InterfaceAlias = $($Interface.Name)

        node localhost {
            
            LocalConfigurationManager {
                ConfigurationMode = "ApplyOnly"
                RebootNodeIfNeeded = $true
            }

            WindowsFeature DNS {
                Name = "DNS"
                Ensure = "Present"
            }

            WindowsFeature DNSTools {
                Name = "RSAT-DNS-Server"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]DNS"
            }

            xDNSServerAddress DNSServerIP {
                Address = "127.0.0.1", "8.8.8.8"
                InterfaceAlias = $InterfaceAlias
                AddressFamily = "IPv4"
                DependsOn = "[WindowsFeature]DNS"
            }

            xWaitForDisk ADDisk {
                DiskId = 2
                RetryIntervalSec = $RetryIntercalSec
                RetryCount = $RetryCount
            }

            xDisk ADVolume {
                DiskId = 2
                DriveLetter = "N"
                FSFormat = "NTFS"
                FSLabel = "Active Directory Data"
                DependsOn = "[xWaitForDisk]ADDisk"
            }

            WindowsFeature ADDSInstall {
                Name = "AD-Domain-Services"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]DNS"
            }

            xADDomain ConfigureAD {
                DomainName = $DomainName
                DomainAdministratorCredential = $DomainCreds
                SafeModeAdministratorPassword = $DomainCreds
                DatabasePath = "N:\NTDS"
                LogPath = "N:\NTDS"
                SysvolPath = "N:\SYSVOL"
                DependsOn = @("[xDisk]ADVolume", "[WindowsFeature]ADDSInstall")
            }

            WindowsFeature ADDSTools {
                Name = "RSAT-ADDS"
                Ensure = "Present"
                IncludeAllSubFeature = $true
                DependsOn = "[WindowsFeature]ADDSInstall"
            }

            WindowsFeature RSAT-RDS-Tools {
                Name = "RSAT-RDS-Tools"
                Ensure = "Present"
                IncludeAllSubFeature = $True
            }

            WindowsFeature RDS-Licensing {
                Name = "RDS-Licensing"
                Ensure = "Present"
            }
        }
    }

configuration xGateway {
    param (
        [parameter(mandatory)][string] $DomainName,
        [parameter(mandatory)][PSCredential] $AdminCreds,
        [int] $RetryCount = 90,
        [int] $RetryIntervalSec = 30
    )

    Import-DscResource -ModuleName xActiveDirectory, xNetworking, xStorage, xComputerManagement
    
    $DomainCreds = New-Object System.Management.Automation.PSCredential ("$DomainName\$($AdminCreds.UserName)", $adminCreds.Password)
    $Interface = Get-NetAdapter | Where-Object Name -like "Ethernet*" | Select-Object -First 1
    $InterfaceAlias = $($Interface.Name)

        node localhost {
            
            LocalConfigurationManager {
                ConfigurationMode = "ApplyOnly"
                RebootNodeIfNeeded = $true
            }

            xDNSServerAddress ConfigureDNS {
                Address = "10.0.2.254"
                InterfaceAlias = $InterfaceAlias
                AddressFamily = "IPv4"
            }

            WindowsFeature ADPowershell {
                Name = "RSAT-AD-PowerShell"
                Ensure = "Present"
            }

            xWaitForADDomain DscForestWait { 
                DomainName = $domainName 
                DomainUserCredential= $domainCreds
                RetryCount = $RetryCount 
                RetryIntervalSec = $RetryIntervalSec 
                DependsOn = "[WindowsFeature]ADPowershell" 
            }

            xComputer DomainJoin-AZSWGW {
                Name = $env:COMPUTERNAME
                DomainName = $DomainName
                Credential = $DomainCreds
                DependsOn = "[xWaitForADDomain]DscForestWait"
            }

            WindowsFeature RDS-Gateway {
                Ensure = "Present"
                Name = "RDS-Gateway"
            }

            WindowsFeature RDS-Web-Access {
                Ensure = "Present"
                Name = "RDS-Web-Access"
            }


        }
    }

configuration xSessionHost {
    param (
        [parameter(mandatory)][string] $DomainName,
        [parameter(mandatory)][PSCredential] $AdminCreds,
        [int] $RetryCount = 90,
        [int] $RetryIntervalSec = 30
    )

    Import-DscResource -ModuleName xActiveDirectory, xNetworking, xStorage, xComputerManagement
    
    $DomainCreds = New-Object System.Management.Automation.PSCredential ("$DomainName\$($AdminCreds.UserName)", $adminCreds.Password)
    $Interface = Get-NetAdapter | Where-Object Name -like "Ethernet*" | Select-Object -First 1
    $InterfaceAlias = $($Interface.Name)

        node localhost {
            
            LocalConfigurationManager {
                ConfigurationMode = "ApplyOnly"
                RebootNodeIfNeeded = $true
            }

            xDNSServerAddress ConfigureDNS {
                Address = "10.0.2.254", "8.8.8.8"
                InterfaceAlias = $InterfaceAlias
                AddressFamily = "IPv4"
            }
            
            WindowsFeature ADPowershell {
                Name = "RSAT-AD-PowerShell"
                Ensure = "Present"
            }

            xWaitForADDomain DscForestWait { 
                DomainName = $domainName 
                DomainUserCredential= $domainCreds
                RetryCount = $RetryCount 
                RetryIntervalSec = $RetryIntervalSec 
                DependsOn = "[WindowsFeature]ADPowershell" 
            }
    
            xComputer DomainJoin-AZSWRDSH {
                Name = $env:COMPUTERNAME
                DomainName = $DomainName
                Credential = $DomainCreds
                DependsOn = "[xWaitForADDomain]DscForestWait"
            }

            WindowsFeature RDS-RD-Server {
                Name = "RDS-RD-Server"
                Ensure = "Present"
            }
        }
    }